Conducting the simulation for the three-dimensional replication and correlated pleiotropy analysis (t=1).



