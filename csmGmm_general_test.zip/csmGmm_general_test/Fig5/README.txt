Please run the code in the Fig3 and Fig6 folder to also create simulation results for Fig5.

Then run "plot_fig_incon.R" to plot the Fig5.


