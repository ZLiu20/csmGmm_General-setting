Please run the code in the Fig7 folder to also create Table 1.


