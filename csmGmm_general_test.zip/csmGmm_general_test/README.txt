Here we detail the steps for reproducing Figure 4 and Tables 1 and 2:

1. Open each of the .R scripts and change the top few lines where necessary, such as to point to the correct output folder.

2. Conducting "Fig1" for three-dimensional pleiotropy analysis

3. Conducting "Fig2" for four-dimensional pleiotropy analysis, and F

4. Make necessary changes to .lsf files, such as using the correct queue names and runtimes.

4. Run the run_analyze_med.lsf and run_pleiotropy_analysis.lsf jobs.

5. After step 4 is completed, run the run_summarize_S1.lsf and run_summarize_S2.lsf jobs.

6. Run the plot_data_analysis.R script to plot Figure 4 and create Tables 1 and 2.

 






