Conducting the simulation for the four-dimensional pleiotropy analysis (t=1 and 2).



