Conducting real data analysis: 
-- two mediator;
-- pleiotropy only;
-- replication only.



