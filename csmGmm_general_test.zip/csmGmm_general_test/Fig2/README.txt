Conducting the simulation for the four-dimensional mediation analysis (t=1).



