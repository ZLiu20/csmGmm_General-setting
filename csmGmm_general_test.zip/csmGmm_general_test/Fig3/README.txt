Conducting the simulation for the three-dimensional pleiotropy analysis (t=1).



